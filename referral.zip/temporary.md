Yellow BTN-BG {
color: black;
box-shadow: 0px 5px 16px -6px rgba(241, 172, 21, 1);
-webkit-box-shadow: 0px 5px 16px -6px rgba(241, 172, 21, 1);
background: linear-gradient(
0deg,
rgba(241, 172, 21, 1) 22%,
rgba(252, 242, 33, 1) 100%
);

}
Yellow BTN-BG:hover {
box-shadow: 0px 0px 4px 2px rgba(241, 172, 21, 1);
-webkit-box-shadow: 0px 0px 4px 2px rgba(241, 172, 21, 1);
background: linear-gradient(
180deg,
rgba(241, 172, 21, 1) 22%,
rgba(252, 242, 33, 1) 100%
);
}

Blue BTN-BG {
color : white;
background : linear-gradient: (0deg, #07276b 22%, #1354a3 100%);
box-shadow :0px 5px 16px -6px rgba(114, 4, 207, 1);
-webkit-box-shadow :0px 5px 16px -6px rgba(114, 4, 207, 1);
}

Blue BTN-BG {
background :linear-gradient(0deg, #1354a3 22%, #07276b 100%)
box-shadow :0px 0px 4px 2px rgba(114, 4, 207, 0.75);
-webkit-box-shadow :0px 0px 4px 2px rgba(114, 4, 207, 0.75);
}
